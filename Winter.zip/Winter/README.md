TutorialWorldGeneration
=======================

A tutorial on the facet world generation system

See the wiki for a [tutorial](https://github.com/Terasology/TutorialWorldGeneration/wiki)

![Facet Production](/images/Facet%20Production.png)
![Noise Sampling](/images/Noise%20Sampling.png)
![Facet Modification](/images/Facet%20Modification.png)
![Houses](/images/Houses.png)
![Lakes](/images/PluginLakes.jpg)
